# App Directory

```txt
App Directory Structure:

└── app/
    ├── layout.tsx
    ├── layout.hooks.tsx
    ├── layout.stores.ts
    ├── layout.actions.ts
    ├── layout.types.ts
    ├── page.tsx
    ├── (auth)/
    │   ├── sign-in/
    │   │   ├── page.tsx
    │   │   └── page.hooks.tsx
    │   ├── sign-up/
    │   │   ├── page.tsx
    │   │   └── page.hooks.tsx
    │   ├── forgot-password/
    │   │   └── page.tsx
    │   ├── reset-password/
    │   │   └── page.tsx
    │   ├── verify/
    │   │   └── page.tsx
    │   └── welcome/
    │       ├── page.tsx
    │       └── page.hooks.tsx
    ├── (admin)/
    │   ├── layout.tsx
    │   ├── layout.hooks.tsx
    │   ├── page.tsx
    │   ├── creators/
    │   │   ├── page.tsx
    │   │   └── page.hooks.tsx
    │   ├── orders/
    │   │   └── page.tsx
    │   ├── vendors/
    │   │   └── page.tsx
    │   ├── quality/
    │   │   └── page.tsx
    │   ├── layout.actions.ts
    │   ├── layout.stores.ts
    │   └── layout.types.ts
    ├── dashboard/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    ├── studio/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    ├── [creatorSlug]/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    ├── subscriptions/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    ├── orders/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    ├── terms/
    │   └── page.tsx
    ├── privacy/
    │   └── page.tsx
    ├── about/
    │   └── page.tsx
    ├── contact/
    │   ├── page.tsx
    │   └── page.hooks.tsx
    └── page.hooks.tsx

```

```txt
Route Map (Generated from App Structure):

├── /
├── /sign-in
├── /sign-up
├── /forgot-password
├── /reset-password
├── /verify
├── /welcome
├── /
├── /creators
├── /orders
├── /vendors
├── /quality
├── /dashboard
├── /studio
├── /[creatorSlug]
├── /subscriptions
├── /orders
├── /terms
├── /privacy
├── /about
└── /contact

```

## Feature and Function Map

### /app/layout.tsx
**Feature: Sign out user**
- Hook: `useSignOut` → `/app/layout.hooks.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `signOutAction` → `/app/layout.actions.ts`
- Type: `SignOutResult` → `/app/layout.types.ts`

**Feature: Toggle profile menu**
- Hook: `useProfileMenu` → `/app/layout.hooks.tsx`
- Store: `useProfileMenuStore` → `/app/layout.stores.ts`
- Action: `toggleProfileMenuAction` → `/app/layout.actions.ts`
- Type: `ProfileMenuState` → `/app/layout.types.ts`

**Feature: Toggle profile menu**
- Hook: `useAdminProfileMenu` → `/app/(admin)/layout.hooks.tsx`
- Store: `useAdminProfileMenuStore` → `/app/layout.stores.ts`
- Action: `toggleAdminProfileMenuAction` → `/app/layout.actions.ts`
- Type: `AdminProfileMenuState` → `/app/layout.types.ts`

### /app/layout.hooks.tsx
- `useSignOut` (used by: `/app/layout.tsx` → Sign out user)
- `useProfileMenu` (used by: `/app/layout.tsx` → Toggle profile menu)

### /app/layout.stores.ts
- `useAuthStore` (used by: `/app/layout.tsx` → Sign out user)
- `useProfileMenuStore` (used by: `/app/layout.tsx` → Toggle profile menu)
- `useAdminProfileMenuStore` (used by: `/app/layout.tsx` → Toggle profile menu)

### /app/layout.actions.ts
- `signOutAction` (used by: `/app/layout.tsx` → Sign out user)
- `toggleProfileMenuAction` (used by: `/app/layout.tsx` → Toggle profile menu)
- `toggleAdminProfileMenuAction` (used by: `/app/layout.tsx` → Toggle profile menu)

### /app/layout.types.ts
- `SignOutResult` (used by: `/app/layout.tsx` → Sign out user)
- `ProfileMenuState` (used by: `/app/layout.tsx` → Toggle profile menu)
- `AdminProfileMenuState` (used by: `/app/layout.tsx` → Toggle profile menu)

### /app/page.tsx
**Feature: Get featured loot boxes**
- Hook: `useFeaturedLootBoxes` → `/app/page.hooks.tsx`
- Store: `useLootBoxStore` → `/app/layout.stores.ts`
- Action: `getFeaturedLootBoxesAction` → `/app/layout.actions.ts`
- Type: `FeaturedLootBox` → `/app/layout.types.ts`

**Feature: Get featured creators**
- Hook: `useFeaturedCreators` → `/app/page.hooks.tsx`
- Store: `useCreatorStore` → `/app/layout.stores.ts`
- Action: `getFeaturedCreatorsAction` → `/app/layout.actions.ts`
- Type: `FeaturedCreator` → `/app/layout.types.ts`

**Feature: Get platform metrics**
- Hook: `usePlatformMetrics` → `/app/(admin)/layout.hooks.tsx`
- Store: `usePlatformMetricsStore` → `/app/(admin)/layout.hooks.tsx`
- Action: `getPlatformMetricsAction` → `/app/(admin)/layout.hooks.tsx`
- Type: `PlatformMetrics` → `/app/(admin)/layout.hooks.tsx`

**Feature: Get active creators**
- Hook: `useActiveCreators` → `/app/(admin)/layout.hooks.tsx`
- Store: `useActiveCreatorsStore` → `/app/(admin)/layout.hooks.tsx`
- Action: `getActiveCreatorsAction` → `/app/(admin)/layout.hooks.tsx`
- Type: `ActiveCreator` → `/app/(admin)/layout.hooks.tsx`

**Feature: Get pending orders**
- Hook: `usePendingOrders` → `/app/(admin)/layout.hooks.tsx`
- Store: `usePendingOrderStore` → `/app/(admin)/layout.hooks.tsx`
- Action: `getPendingOrdersAction` → `/app/(admin)/layout.hooks.tsx`
- Type: `PendingOrder` → `/app/(admin)/layout.hooks.tsx`

**Feature: Get system status**
- Hook: `useSystemStatus` → `/app/(admin)/layout.hooks.tsx`
- Store: `useSystemStatusStore` → `/app/(admin)/layout.hooks.tsx`
- Action: `getSystemStatusAction` → `/app/(admin)/layout.hooks.tsx`
- Type: `SystemStatus` → `/app/(admin)/layout.hooks.tsx`

**Feature: Get creator applications**
- Hook: `useCreatorApplications` → `/app/(admin)/creators/page.hooks.tsx`
- Store: `useCreatorApplicationStore` → `/app/(admin)/creators/page.hooks.tsx`
- Action: `getCreatorApplicationsAction` → `/app/(admin)/creators/page.hooks.tsx`
- Type: `CreatorApplication` → `/app/(admin)/creators/page.hooks.tsx`

**Feature: Approve creator application**
- Hook: `useApproveCreator` → `/app/(admin)/layout.hooks.tsx`
- Store: `useCreatorApprovalStore` → `/app/(admin)/layout.stores.ts`
- Action: `approveCreatorAction` → `/app/(admin)/layout.actions.ts`
- Type: `CreatorApprovalData` → `/app/(admin)/layout.types.ts`

**Feature: Reject creator application**
- Hook: `useRejectCreator` → `/app/(admin)/layout.hooks.tsx`
- Store: `useCreatorRejectionStore` → `/app/(admin)/layout.stores.ts`
- Action: `rejectCreatorAction` → `/app/(admin)/layout.actions.ts`
- Type: `CreatorRejectionData` → `/app/(admin)/layout.types.ts`

**Feature: Suspend creator account**
- Hook: `useSuspendCreator` → `/app/(admin)/layout.hooks.tsx`
- Store: `useCreatorSuspensionStore` → `/app/(admin)/layout.stores.ts`
- Action: `suspendCreatorAction` → `/app/(admin)/layout.actions.ts`
- Type: `CreatorSuspensionData` → `/app/(admin)/layout.types.ts`

**Feature: Get pending orders**
- Hook: `usePendingOrders` → `/app/(admin)/layout.hooks.tsx`
- Store: `usePendingOrderStore` → `/app/(admin)/layout.stores.ts`
- Action: `getPendingOrdersAction` → `/app/(admin)/layout.actions.ts`
- Type: `PendingOrder` → `/app/(admin)/layout.types.ts`

**Feature: Update order status**
- Hook: `useUpdateOrderStatus` → `/app/(admin)/layout.hooks.tsx`
- Store: `useOrderStatusStore` → `/app/(admin)/layout.stores.ts`
- Action: `updateOrderStatusAction` → `/app/(admin)/layout.actions.ts`
- Type: `OrderStatusUpdate` → `/app/(admin)/layout.types.ts`

**Feature: Assign order to vendor**
- Hook: `useAssignVendor` → `/app/(admin)/layout.hooks.tsx`
- Store: `useVendorAssignmentStore` → `/app/(admin)/layout.stores.ts`
- Action: `assignVendorAction` → `/app/(admin)/layout.actions.ts`
- Type: `VendorAssignmentData` → `/app/(admin)/layout.types.ts`

**Feature: Get vendor list**
- Hook: `useVendorList` → `/app/(admin)/layout.hooks.tsx`
- Store: `useVendorListStore` → `/app/(admin)/layout.stores.ts`
- Action: `getVendorListAction` → `/app/(admin)/layout.actions.ts`
- Type: `VendorListItem` → `/app/(admin)/layout.types.ts`

**Feature: Add new vendor**
- Hook: `useAddVendor` → `/app/(admin)/layout.hooks.tsx`
- Store: `useVendorCreationStore` → `/app/(admin)/layout.stores.ts`
- Action: `addVendorAction` → `/app/(admin)/layout.actions.ts`
- Type: `VendorCreateData` → `/app/(admin)/layout.types.ts`

**Feature: Update vendor details**
- Hook: `useUpdateVendor` → `/app/(admin)/layout.hooks.tsx`
- Store: `useVendorUpdateStore` → `/app/(admin)/layout.stores.ts`
- Action: `updateVendorAction` → `/app/(admin)/layout.actions.ts`
- Type: `VendorUpdateData` → `/app/(admin)/layout.types.ts`

**Feature: Deactivate vendor**
- Hook: `useDeactivateVendor` → `/app/(admin)/layout.hooks.tsx`
- Store: `useVendorDeactivationStore` → `/app/(admin)/layout.stores.ts`
- Action: `deactivateVendorAction` → `/app/(admin)/layout.actions.ts`
- Type: `VendorDeactivationData` → `/app/(admin)/layout.types.ts`

**Feature: Get pending reviews**
- Hook: `usePendingReviews` → `/app/(admin)/layout.hooks.tsx`
- Store: `useQualityReviewStore` → `/app/(admin)/layout.stores.ts`
- Action: `getPendingReviewsAction` → `/app/(admin)/layout.actions.ts`
- Type: `PendingReviewItem` → `/app/(admin)/layout.types.ts`

**Feature: Approve product**
- Hook: `useApproveProduct` → `/app/(admin)/layout.hooks.tsx`
- Store: `useProductApprovalStore` → `/app/(admin)/layout.stores.ts`
- Action: `approveProductAction` → `/app/(admin)/layout.actions.ts`
- Type: `ProductApprovalData` → `/app/(admin)/layout.types.ts`

**Feature: Reject product**
- Hook: `useRejectProduct` → `/app/(admin)/layout.hooks.tsx`
- Store: `useProductRejectionStore` → `/app/(admin)/layout.stores.ts`
- Action: `rejectProductAction` → `/app/(admin)/layout.actions.ts`
- Type: `ProductRejectionData` → `/app/(admin)/layout.types.ts`

### /app/(auth)/sign-in/page.tsx
**Feature: Sign in with email and password**
- Hook: `useSignIn` → `/app/(auth)/sign-in/page.hooks.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `signInAction` → `/app/layout.actions.ts`
- Type: `SignInCredentials` → `/app/layout.types.ts`

**Feature: Send magic link email**
- Hook: `useMagicLink` → `/app/(auth)/sign-in/page.hooks.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `sendMagicLinkAction` → `/app/layout.actions.ts`
- Type: `MagicLinkRequest` → `/app/layout.types.ts`

### /app/(auth)/sign-in/page.hooks.tsx
- `useSignIn` (used by: `/app/(auth)/sign-in/page.tsx` → Sign in with email and password)
- `useMagicLink` (used by: `/app/(auth)/sign-in/page.tsx` → Send magic link email)

### /app/(auth)/sign-up/page.tsx
**Feature: Create account with email and password**
- Hook: `useSignUp` → `/app/(auth)/sign-up/page.hooks.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `signUpAction` → `/app/layout.actions.ts`
- Type: `SignUpCredentials` → `/app/layout.types.ts`

**Feature: Send magic link signup email**
- Hook: `useSignUpMagicLink` → `/app/(auth)/sign-up/page.hooks.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `sendSignUpMagicLinkAction` → `/app/layout.actions.ts`
- Type: `SignUpMagicLinkRequest` → `/app/layout.types.ts`

### /app/(auth)/sign-up/page.hooks.tsx
- `useSignUp` (used by: `/app/(auth)/sign-up/page.tsx` → Create account with email and password)
- `useSignUpMagicLink` (used by: `/app/(auth)/sign-up/page.tsx` → Send magic link signup email)

### /app/(auth)/forgot-password/page.tsx
**Feature: Send password reset email**
- Hook: `usePasswordReset` → `/app/(auth)/forgot-password/page.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `sendPasswordResetAction` → `/app/layout.actions.ts`
- Type: `PasswordResetRequest` → `/app/layout.types.ts`

### /app/(auth)/reset-password/page.tsx
**Feature: Reset user password**
- Hook: `useResetPassword` → `/app/(auth)/reset-password/page.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `resetPasswordAction` → `/app/layout.actions.ts`
- Type: `ResetPasswordData` → `/app/layout.types.ts`

### /app/(auth)/verify/page.tsx
**Feature: Verify email address**
- Hook: `useVerifyEmail` → `/app/(auth)/verify/page.tsx`
- Store: `useAuthStore` → `/app/layout.stores.ts`
- Action: `verifyEmailAction` → `/app/layout.actions.ts`
- Type: `EmailVerificationData` → `/app/layout.types.ts`

### /app/(auth)/welcome/page.tsx
**Feature: Complete user profile**
- Hook: `useCompleteProfile` → `/app/(auth)/welcome/page.hooks.tsx`
- Store: `useProfileStore` → `/app/layout.stores.ts`
- Action: `completeProfileAction` → `/app/layout.actions.ts`
- Type: `UserProfileData` → `/app/layout.types.ts`

**Feature: Upload profile picture**
- Hook: `useProfilePictureUpload` → `/app/(auth)/welcome/page.hooks.tsx`
- Store: `useProfileStore` → `/app/layout.stores.ts`
- Action: `uploadProfilePictureAction` → `/app/layout.actions.ts`
- Type: `ProfilePictureData` → `/app/layout.types.ts`

### /app/(auth)/welcome/page.hooks.tsx
- `useCompleteProfile` (used by: `/app/(auth)/welcome/page.tsx` → Complete user profile)
- `useProfilePictureUpload` (used by: `/app/(auth)/welcome/page.tsx` → Upload profile picture)

### /app/(admin)/layout.tsx
*No features defined*

### /app/(admin)/layout.hooks.tsx
- `useAdminProfileMenu` (used by: `/app/layout.tsx` → Toggle profile menu)
- `usePlatformMetrics` (used by: `/app/page.tsx` → Get platform metrics)
- `usePlatformMetricsStore` (used by: `/app/page.tsx` → Get platform metrics)
- `getPlatformMetricsAction` (used by: `/app/page.tsx` → Get platform metrics)
- `PlatformMetrics` (used by: `/app/page.tsx` → Get platform metrics)
- `useActiveCreators` (used by: `/app/page.tsx` → Get active creators)
- `useActiveCreatorsStore` (used by: `/app/page.tsx` → Get active creators)
- `getActiveCreatorsAction` (used by: `/app/page.tsx` → Get active creators)
- `ActiveCreator` (used by: `/app/page.tsx` → Get active creators)
- `usePendingOrders` (used by: `/app/page.tsx` → Get pending orders)
- `usePendingOrderStore` (used by: `/app/page.tsx` → Get pending orders)
- `getPendingOrdersAction` (used by: `/app/page.tsx` → Get pending orders)
- `PendingOrder` (used by: `/app/page.tsx` → Get pending orders)
- `useSystemStatus` (used by: `/app/page.tsx` → Get system status)
- `useSystemStatusStore` (used by: `/app/page.tsx` → Get system status)
- `getSystemStatusAction` (used by: `/app/page.tsx` → Get system status)
- `SystemStatus` (used by: `/app/page.tsx` → Get system status)
- `useApproveCreator` (used by: `/app/page.tsx` → Approve creator application)
- `useRejectCreator` (used by: `/app/page.tsx` → Reject creator application)
- `useSuspendCreator` (used by: `/app/page.tsx` → Suspend creator account)
- `usePendingOrders` (used by: `/app/page.tsx` → Get pending orders)
- `useUpdateOrderStatus` (used by: `/app/page.tsx` → Update order status)
- `useAssignVendor` (used by: `/app/page.tsx` → Assign order to vendor)
- `useVendorList` (used by: `/app/page.tsx` → Get vendor list)
- `useAddVendor` (used by: `/app/page.tsx` → Add new vendor)
- `useUpdateVendor` (used by: `/app/page.tsx` → Update vendor details)
- `useDeactivateVendor` (used by: `/app/page.tsx` → Deactivate vendor)
- `usePendingReviews` (used by: `/app/page.tsx` → Get pending reviews)
- `useApproveProduct` (used by: `/app/page.tsx` → Approve product)
- `useRejectProduct` (used by: `/app/page.tsx` → Reject product)

### /app/(admin)/page.tsx
*No features defined*

### /app/(admin)/creators/page.tsx
*No features defined*

### /app/(admin)/creators/page.hooks.tsx
- `useCreatorApplications` (used by: `/app/page.tsx` → Get creator applications)
- `useCreatorApplicationStore` (used by: `/app/page.tsx` → Get creator applications)
- `getCreatorApplicationsAction` (used by: `/app/page.tsx` → Get creator applications)
- `CreatorApplication` (used by: `/app/page.tsx` → Get creator applications)

### /app/(admin)/orders/page.tsx
**Feature: Get order history**
- Hook: `useOrderHistory` → `/app/orders/page.hooks.tsx`
- Store: `useOrderHistoryStore` → `/app/orders/page.hooks.tsx`
- Action: `getOrderHistoryAction` → `/app/orders/page.hooks.tsx`
- Type: `OrderHistoryItem` → `/app/orders/page.hooks.tsx`

**Feature: Get shipping status**
- Hook: `useShippingStatus` → `/app/orders/page.hooks.tsx`
- Store: `useShippingTrackingStore` → `/app/orders/page.hooks.tsx`
- Action: `getShippingStatusAction` → `/app/orders/page.hooks.tsx`
- Type: `ShippingStatus` → `/app/orders/page.hooks.tsx`

### /app/(admin)/vendors/page.tsx
*No features defined*

### /app/(admin)/quality/page.tsx
*No features defined*

### /app/(admin)/layout.actions.ts
- `approveCreatorAction` (used by: `/app/page.tsx` → Approve creator application)
- `rejectCreatorAction` (used by: `/app/page.tsx` → Reject creator application)
- `suspendCreatorAction` (used by: `/app/page.tsx` → Suspend creator account)
- `getPendingOrdersAction` (used by: `/app/page.tsx` → Get pending orders)
- `updateOrderStatusAction` (used by: `/app/page.tsx` → Update order status)
- `assignVendorAction` (used by: `/app/page.tsx` → Assign order to vendor)
- `getVendorListAction` (used by: `/app/page.tsx` → Get vendor list)
- `addVendorAction` (used by: `/app/page.tsx` → Add new vendor)
- `updateVendorAction` (used by: `/app/page.tsx` → Update vendor details)
- `deactivateVendorAction` (used by: `/app/page.tsx` → Deactivate vendor)
- `getPendingReviewsAction` (used by: `/app/page.tsx` → Get pending reviews)
- `approveProductAction` (used by: `/app/page.tsx` → Approve product)
- `rejectProductAction` (used by: `/app/page.tsx` → Reject product)

### /app/(admin)/layout.stores.ts
- `useCreatorApprovalStore` (used by: `/app/page.tsx` → Approve creator application)
- `useCreatorRejectionStore` (used by: `/app/page.tsx` → Reject creator application)
- `useCreatorSuspensionStore` (used by: `/app/page.tsx` → Suspend creator account)
- `usePendingOrderStore` (used by: `/app/page.tsx` → Get pending orders)
- `useOrderStatusStore` (used by: `/app/page.tsx` → Update order status)
- `useVendorAssignmentStore` (used by: `/app/page.tsx` → Assign order to vendor)
- `useVendorListStore` (used by: `/app/page.tsx` → Get vendor list)
- `useVendorCreationStore` (used by: `/app/page.tsx` → Add new vendor)
- `useVendorUpdateStore` (used by: `/app/page.tsx` → Update vendor details)
- `useVendorDeactivationStore` (used by: `/app/page.tsx` → Deactivate vendor)
- `useQualityReviewStore` (used by: `/app/page.tsx` → Get pending reviews)
- `useProductApprovalStore` (used by: `/app/page.tsx` → Approve product)
- `useProductRejectionStore` (used by: `/app/page.tsx` → Reject product)

### /app/(admin)/layout.types.ts
- `CreatorApprovalData` (used by: `/app/page.tsx` → Approve creator application)
- `CreatorRejectionData` (used by: `/app/page.tsx` → Reject creator application)
- `CreatorSuspensionData` (used by: `/app/page.tsx` → Suspend creator account)
- `PendingOrder` (used by: `/app/page.tsx` → Get pending orders)
- `OrderStatusUpdate` (used by: `/app/page.tsx` → Update order status)
- `VendorAssignmentData` (used by: `/app/page.tsx` → Assign order to vendor)
- `VendorListItem` (used by: `/app/page.tsx` → Get vendor list)
- `VendorCreateData` (used by: `/app/page.tsx` → Add new vendor)
- `VendorUpdateData` (used by: `/app/page.tsx` → Update vendor details)
- `VendorDeactivationData` (used by: `/app/page.tsx` → Deactivate vendor)
- `PendingReviewItem` (used by: `/app/page.tsx` → Get pending reviews)
- `ProductApprovalData` (used by: `/app/page.tsx` → Approve product)
- `ProductRejectionData` (used by: `/app/page.tsx` → Reject product)

### /app/dashboard/page.tsx
**Feature: Get creator analytics**
- Hook: `useCreatorAnalytics` → `/app/dashboard/page.hooks.tsx`
- Store: `useAnalyticsStore` → `/app/layout.stores.ts`
- Action: `getCreatorAnalyticsAction` → `/app/layout.actions.ts`
- Type: `CreatorAnalytics` → `/app/layout.types.ts`

**Feature: Get active loot boxes**
- Hook: `useActiveLootBoxes` → `/app/dashboard/page.hooks.tsx`
- Store: `useCreatorLootBoxStore` → `/app/layout.stores.ts`
- Action: `getActiveLootBoxesAction` → `/app/layout.actions.ts`
- Type: `ActiveLootBox` → `/app/layout.types.ts`

**Feature: Get recent orders**
- Hook: `useRecentOrders` → `/app/dashboard/page.hooks.tsx`
- Store: `useOrderStore` → `/app/layout.stores.ts`
- Action: `getRecentOrdersAction` → `/app/layout.actions.ts`
- Type: `RecentOrder` → `/app/layout.types.ts`

**Feature: Edit loot box details**
- Hook: `useEditLootBox` → `/app/dashboard/page.hooks.tsx`
- Store: `useLootBoxEditStore` → `/app/layout.stores.ts`
- Action: `editLootBoxAction` → `/app/layout.actions.ts`
- Type: `LootBoxEditData` → `/app/layout.types.ts`

**Feature: Delete loot box**
- Hook: `useDeleteLootBox` → `/app/dashboard/page.hooks.tsx`
- Store: `useLootBoxDeleteStore` → `/app/layout.stores.ts`
- Action: `deleteLootBoxAction` → `/app/layout.actions.ts`
- Type: `LootBoxDeleteResult` → `/app/layout.types.ts`

### /app/dashboard/page.hooks.tsx
- `useCreatorAnalytics` (used by: `/app/dashboard/page.tsx` → Get creator analytics)
- `useActiveLootBoxes` (used by: `/app/dashboard/page.tsx` → Get active loot boxes)
- `useRecentOrders` (used by: `/app/dashboard/page.tsx` → Get recent orders)
- `useEditLootBox` (used by: `/app/dashboard/page.tsx` → Edit loot box details)
- `useDeleteLootBox` (used by: `/app/dashboard/page.tsx` → Delete loot box)

### /app/studio/page.tsx
**Feature: Create new product**
- Hook: `useCreateProduct` → `/app/studio/page.hooks.tsx`
- Store: `useProductStore` → `/app/layout.stores.ts`
- Action: `createProductAction` → `/app/layout.actions.ts`
- Type: `ProductCreateData` → `/app/layout.types.ts`

**Feature: Upload product artwork**
- Hook: `useProductArtworkUpload` → `/app/studio/page.hooks.tsx`
- Store: `useArtworkStore` → `/app/layout.stores.ts`
- Action: `uploadProductArtworkAction` → `/app/layout.actions.ts`
- Type: `ProductArtworkData` → `/app/layout.types.ts`

**Feature: Save product draft**
- Hook: `useProductDraft` → `/app/studio/page.hooks.tsx`
- Store: `useProductDraftStore` → `/app/layout.stores.ts`
- Action: `saveProductDraftAction` → `/app/layout.actions.ts`
- Type: `ProductDraftData` → `/app/layout.types.ts`

**Feature: Submit product for review**
- Hook: `useProductSubmission` → `/app/studio/page.hooks.tsx`
- Store: `useProductSubmissionStore` → `/app/layout.stores.ts`
- Action: `submitProductReviewAction` → `/app/layout.actions.ts`
- Type: `ProductSubmissionData` → `/app/layout.types.ts`

### /app/studio/page.hooks.tsx
- `useCreateProduct` (used by: `/app/studio/page.tsx` → Create new product)
- `useProductArtworkUpload` (used by: `/app/studio/page.tsx` → Upload product artwork)
- `useProductDraft` (used by: `/app/studio/page.tsx` → Save product draft)
- `useProductSubmission` (used by: `/app/studio/page.tsx` → Submit product for review)

### /app/[creatorSlug]/page.tsx
**Feature: Get creator profile**
- Hook: `useCreatorProfile` → `/app/[creatorSlug]/page.tsx`
- Store: `useCreatorProfileStore` → `/app/layout.stores.ts`
- Action: `getCreatorProfileAction` → `/app/layout.actions.ts`
- Type: `CreatorProfileData` → `/app/layout.types.ts`

**Feature: Get available subscriptions**
- Hook: `useAvailableSubscriptions` → `/app/[creatorSlug]/page.hooks.tsx`
- Store: `useSubscriptionTierStore` → `/app/[creatorSlug]/page.hooks.tsx`
- Action: `getAvailableSubscriptionsAction` → `/app/[creatorSlug]/page.hooks.tsx`
- Type: `SubscriptionTier` → `/app/[creatorSlug]/page.hooks.tsx`

**Feature: Subscribe to creator**
- Hook: `useSubscribeCreator` → `/app/[creatorSlug]/page.hooks.tsx`
- Store: `useSubscriptionStore` → `/app/[creatorSlug]/page.hooks.tsx`
- Action: `subscribeCreatorAction` → `/app/[creatorSlug]/page.hooks.tsx`
- Type: `SubscriptionRequest` → `/app/[creatorSlug]/page.hooks.tsx`

### /app/[creatorSlug]/page.hooks.tsx
- `useAvailableSubscriptions` (used by: `/app/[creatorSlug]/page.tsx` → Get available subscriptions)
- `useSubscriptionTierStore` (used by: `/app/[creatorSlug]/page.tsx` → Get available subscriptions)
- `getAvailableSubscriptionsAction` (used by: `/app/[creatorSlug]/page.tsx` → Get available subscriptions)
- `SubscriptionTier` (used by: `/app/[creatorSlug]/page.tsx` → Get available subscriptions)
- `useSubscribeCreator` (used by: `/app/[creatorSlug]/page.tsx` → Subscribe to creator)
- `useSubscriptionStore` (used by: `/app/[creatorSlug]/page.tsx` → Subscribe to creator)
- `subscribeCreatorAction` (used by: `/app/[creatorSlug]/page.tsx` → Subscribe to creator)
- `SubscriptionRequest` (used by: `/app/[creatorSlug]/page.tsx` → Subscribe to creator)

### /app/subscriptions/page.tsx
**Feature: Get active subscriptions**
- Hook: `useActiveSubscriptions` → `/app/subscriptions/page.hooks.tsx`
- Store: `useUserSubscriptionStore` → `/app/subscriptions/page.hooks.tsx`
- Action: `getActiveSubscriptionsAction` → `/app/subscriptions/page.hooks.tsx`
- Type: `ActiveSubscription` → `/app/subscriptions/page.hooks.tsx`

**Feature: Cancel subscription**
- Hook: `useCancelSubscription` → `/app/subscriptions/page.hooks.tsx`
- Store: `useSubscriptionCancelStore` → `/app/subscriptions/page.hooks.tsx`
- Action: `cancelSubscriptionAction` → `/app/subscriptions/page.hooks.tsx`
- Type: `SubscriptionCancelResult` → `/app/subscriptions/page.hooks.tsx`

**Feature: Update payment method**
- Hook: `useUpdatePaymentMethod` → `/app/subscriptions/page.hooks.tsx`
- Store: `usePaymentMethodStore` → `/app/subscriptions/page.hooks.tsx`
- Action: `updatePaymentMethodAction` → `/app/subscriptions/page.hooks.tsx`
- Type: `PaymentMethodData` → `/app/subscriptions/page.hooks.tsx`

### /app/subscriptions/page.hooks.tsx
- `useActiveSubscriptions` (used by: `/app/subscriptions/page.tsx` → Get active subscriptions)
- `useUserSubscriptionStore` (used by: `/app/subscriptions/page.tsx` → Get active subscriptions)
- `getActiveSubscriptionsAction` (used by: `/app/subscriptions/page.tsx` → Get active subscriptions)
- `ActiveSubscription` (used by: `/app/subscriptions/page.tsx` → Get active subscriptions)
- `useCancelSubscription` (used by: `/app/subscriptions/page.tsx` → Cancel subscription)
- `useSubscriptionCancelStore` (used by: `/app/subscriptions/page.tsx` → Cancel subscription)
- `cancelSubscriptionAction` (used by: `/app/subscriptions/page.tsx` → Cancel subscription)
- `SubscriptionCancelResult` (used by: `/app/subscriptions/page.tsx` → Cancel subscription)
- `useUpdatePaymentMethod` (used by: `/app/subscriptions/page.tsx` → Update payment method)
- `usePaymentMethodStore` (used by: `/app/subscriptions/page.tsx` → Update payment method)
- `updatePaymentMethodAction` (used by: `/app/subscriptions/page.tsx` → Update payment method)
- `PaymentMethodData` (used by: `/app/subscriptions/page.tsx` → Update payment method)

### /app/orders/page.tsx
**Feature: Get order history**
- Hook: `useOrderHistory` → `/app/orders/page.hooks.tsx`
- Store: `useOrderHistoryStore` → `/app/orders/page.hooks.tsx`
- Action: `getOrderHistoryAction` → `/app/orders/page.hooks.tsx`
- Type: `OrderHistoryItem` → `/app/orders/page.hooks.tsx`

**Feature: Get shipping status**
- Hook: `useShippingStatus` → `/app/orders/page.hooks.tsx`
- Store: `useShippingTrackingStore` → `/app/orders/page.hooks.tsx`
- Action: `getShippingStatusAction` → `/app/orders/page.hooks.tsx`
- Type: `ShippingStatus` → `/app/orders/page.hooks.tsx`

### /app/orders/page.hooks.tsx
- `useOrderHistory` (used by: `/app/(admin)/orders/page.tsx` → Get order history)
- `useOrderHistoryStore` (used by: `/app/(admin)/orders/page.tsx` → Get order history)
- `getOrderHistoryAction` (used by: `/app/(admin)/orders/page.tsx` → Get order history)
- `OrderHistoryItem` (used by: `/app/(admin)/orders/page.tsx` → Get order history)
- `useShippingStatus` (used by: `/app/(admin)/orders/page.tsx` → Get shipping status)
- `useShippingTrackingStore` (used by: `/app/(admin)/orders/page.tsx` → Get shipping status)
- `getShippingStatusAction` (used by: `/app/(admin)/orders/page.tsx` → Get shipping status)
- `ShippingStatus` (used by: `/app/(admin)/orders/page.tsx` → Get shipping status)
- `useOrderHistory` (used by: `/app/orders/page.tsx` → Get order history)
- `useOrderHistoryStore` (used by: `/app/orders/page.tsx` → Get order history)
- `getOrderHistoryAction` (used by: `/app/orders/page.tsx` → Get order history)
- `OrderHistoryItem` (used by: `/app/orders/page.tsx` → Get order history)
- `useShippingStatus` (used by: `/app/orders/page.tsx` → Get shipping status)
- `useShippingTrackingStore` (used by: `/app/orders/page.tsx` → Get shipping status)
- `getShippingStatusAction` (used by: `/app/orders/page.tsx` → Get shipping status)
- `ShippingStatus` (used by: `/app/orders/page.tsx` → Get shipping status)

### /app/terms/page.tsx
*No features defined*

### /app/privacy/page.tsx
*No features defined*

### /app/about/page.tsx
*No features defined*

### /app/contact/page.tsx
**Feature: Submit contact form**
- Hook: `useContactForm` → `/app/contact/page.hooks.tsx`
- Store: `useContactFormStore` → `/app/layout.stores.ts`
- Action: `submitContactFormAction` → `/app/layout.actions.ts`
- Type: `ContactFormData` → `/app/layout.types.ts`

### /app/contact/page.hooks.tsx
- `useContactForm` (used by: `/app/contact/page.tsx` → Submit contact form)

### /app/page.hooks.tsx
- `useFeaturedLootBoxes` (used by: `/app/page.tsx` → Get featured loot boxes)
- `useFeaturedCreators` (used by: `/app/page.tsx` → Get featured creators)

