<!-- component-READMEComponent -->

# Loot.ForSale

Loot.ForSale is a creative marketplace where makers, artists, and enthusiasts can create and sell their own mystery subscription boxes filled with unique physical goods. Whether you're passionate about crafting, art, collectibles, or themed merchandise, you can design custom products and package them into exciting monthly surprises for your subscribers.

As a creator, you'll get your own branded storefront where you can showcase your loot box offerings at different price points and subscription lengths. You have the freedom to design custom merchandise like shirts, mugs, stickers, 3D-printed items, and more – all while we handle the manufacturing and shipping logistics for you.

For subscribers, Loot.ForSale offers a delightful way to receive curated collections of unique items from creators they love. While the specific contents remain a mystery until delivery, each box follows a clear theme so subscribers know what style of items to expect. It's like getting a surprise gift picked just for you, month after month.

## Layouts

### Main Layout

**Components:** Header (app title, navigation, profile menu), Footer (app title, all nav items, legal links)

**Pages using this layout:**
- Home (`/`)
- Creator Dashboard (`/dashboard`)
- Creator Studio (`/studio`)
- Creator Store (`/[creatorSlug]`)
- Subscription Management (`/subscriptions`)
- Order History (`/orders`)

### Admin Layout

**Components:** Header (app title, profile menu, sticky, sidebar toggle), Left Sidebar (navigation, profile menu)

**Pages using this layout:**
- Admin Dashboard (`/admin`)
- Creator Management (`/admin/creators`)
- Order Management (`/admin/orders`)
- Vendor Management (`/admin/vendors`)
- Quality Control (`/admin/quality`)

## Pages

### Sign In (`/sign-in`)

**Access:** 🌐 Anon


Users can select between email only sign in to receive a magic link for passwordless sign-in, or email and password sign in

### Sign Up (`/sign-up`)

**Access:** 🌐 Anon


Users can select between creating an account with email only via magic link sign up, or email and password sign up

### Forgot Password (`/forgot-password`)

**Access:** 🌐 Anon


Where users request a password reset link

### Reset Password (`/reset-password`)

**Access:** 🌐 Anon


Where users set a new password after clicking the reset link

### Verify Email (`/verify`)

**Access:** 🌐 Anon


Email verification page that displays a message informing users to check their inbox and click the verification link to complete their account setup and sign in.

### Welcome (`/welcome`)

**Access:** 🔐 Auth | 👑 Admin


First-time user profile setup after initial sign in. All relevant profile data is collected

### Home (`/`)

**Access:** 🌐 Anon | 🔐 Auth
**Layouts:** Main Layout


Landing page showcasing popular loot boxes, featured creators, and platform benefits. Visitors can browse available subscriptions and learn about becoming a creator.

### Creator Dashboard (`/dashboard`)

**Access:** 🔐 Auth
**Layouts:** Main Layout


Central hub for creators to manage their loot box offerings, view analytics, track orders, and access design tools for creating new products.

### Creator Studio (`/studio`)

**Access:** 🔐 Auth
**Layouts:** Main Layout


Design interface for creators to develop new products using platform tools for print-on-demand items, 3D prints, stickers, and zines.

### Creator Store (`/[creatorSlug]`)

**Access:** 🌐 Anon | 🔐 Auth
**Layouts:** Main Layout


Public storefront for each creator's branded subdomain, displaying their available loot box tiers and subscription options.

### Subscription Management (`/subscriptions`)

**Access:** 🔐 Auth
**Layouts:** Main Layout


Customer portal for managing active subscriptions, viewing past boxes, and updating billing information.

### Order History (`/orders`)

**Access:** 🔐 Auth
**Layouts:** Main Layout


Detailed view of past and current orders, shipping status, and delivery tracking for customers.

### Admin Dashboard (`/admin`)

**Access:** 👑 Admin
**Layouts:** Admin Layout


Overview of platform metrics, active creators, orders requiring attention, and system health status.

### Creator Management (`/admin/creators`)

**Access:** 👑 Admin
**Layouts:** Admin Layout


Administrative tools for managing creator accounts, reviewing applications, and monitoring content compliance.

### Order Management (`/admin/orders`)

**Access:** 👑 Admin
**Layouts:** Admin Layout


Interface for managing order fulfillment, coordinating with vendors, and resolving shipping issues.

### Vendor Management (`/admin/vendors`)

**Access:** 👑 Admin
**Layouts:** Admin Layout


Tools for managing relationships with print shops, 3D printing services, and other fulfillment partners.

### Quality Control (`/admin/quality`)

**Access:** 👑 Admin
**Layouts:** Admin Layout


System for reviewing product submissions, checking manufacturing quality, and managing quality control processes.

### Terms and Conditions (`/terms`)

**Access:** 🌐 Anon | 🔐 Auth | 👑 Admin


Legal terms and conditions governing the use of the service, including user responsibilities, acceptable use policy, and liability disclaimers

### Privacy Policy (`/privacy`)

**Access:** 🌐 Anon | 🔐 Auth | 👑 Admin


Privacy policy detailing how user data is collected, used, stored, and protected, including information about cookies and third-party services

### About (`/about`)

**Access:** 🌐 Anon | 🔐 Auth | 👑 Admin


Information about the company or organization, mission statement, team information, and company history

### Contact (`/contact`)

**Access:** 🌐 Anon | 🔐 Auth | 👑 Admin


Contact page with email form for inquiries and business contact details including address, phone number, and support email

## Authentication & Access Control

**Authentication Methods:** Email & Password, Magic Link

**Access Levels:**
- 🌐 Anonymous: 11 pages
- 🔐 Authenticated: 11 pages
- 👑 Admin: 10 pages

**Page Access:**

- **Sign In** (`/sign-in`) - 🌐 Anon
- **Sign Up** (`/sign-up`) - 🌐 Anon
- **Forgot Password** (`/forgot-password`) - 🌐 Anon
- **Reset Password** (`/reset-password`) - 🌐 Anon
- **Verify Email** (`/verify`) - 🌐 Anon
- **Welcome** (`/welcome`) - 🔐 Auth, 👑 Admin
- **Home** (`/`) - 🌐 Anon, 🔐 Auth
- **Creator Dashboard** (`/dashboard`) - 🔐 Auth
- **Creator Studio** (`/studio`) - 🔐 Auth
- **Creator Store** (`/[creatorSlug]`) - 🌐 Anon, 🔐 Auth
- **Subscription Management** (`/subscriptions`) - 🔐 Auth
- **Order History** (`/orders`) - 🔐 Auth
- **Admin Dashboard** (`/admin`) - 👑 Admin
- **Creator Management** (`/admin/creators`) - 👑 Admin
- **Order Management** (`/admin/orders`) - 👑 Admin
- **Vendor Management** (`/admin/vendors`) - 👑 Admin
- **Quality Control** (`/admin/quality`) - 👑 Admin
- **Terms and Conditions** (`/terms`) - 🌐 Anon, 🔐 Auth, 👑 Admin
- **Privacy Policy** (`/privacy`) - 🌐 Anon, 🔐 Auth, 👑 Admin
- **About** (`/about`) - 🌐 Anon, 🔐 Auth, 👑 Admin
- **Contact** (`/contact`) - 🌐 Anon, 🔐 Auth, 👑 Admin

## Getting Started

Getting started with Loot.ForSale is easy! Visit loot.forsale and sign up using your email address – you can either create a password or use our convenient magic link option sent straight to your inbox. Once logged in, choose whether you want to browse and subscribe to existing loot boxes, or become a creator yourself.

New creators will be guided through setting up their storefront, designing their first products, and creating their initial loot box offerings. Subscribers can immediately start exploring creator stores, view available box themes and tiers, and sign up for their first subscription. Both creators and subscribers get access to a dashboard to manage their accounts, track orders, and connect with the community.
