# Database

```sql
-- Create user_role enum type
-- Defines application-level roles stored in profiles.role column
-- These are NOT Postgres roles - they are checked in RLS policies using helper functions
CREATE TYPE user_role AS ENUM ('user', 'admin', 'super-admin');

-- Create enum types
CREATE TYPE creator_status AS ENUM ('pending', 'active', 'suspended');
CREATE TYPE box_status AS ENUM ('draft', 'pending_review', 'active', 'archived');
CREATE TYPE item_type AS ENUM ('print_on_demand', 'three_d_print', 'sticker', 'zine');
CREATE TYPE item_status AS ENUM ('draft', 'pending_review', 'approved', 'rejected');
CREATE TYPE subscription_status AS ENUM ('active', 'past_due', 'cancelled');
CREATE TYPE order_status AS ENUM ('pending', 'processing', 'shipped', 'delivered', 'cancelled');
CREATE TYPE fulfillment_status AS ENUM ('pending', 'assigned', 'in_production', 'shipped', 'completed');
CREATE TYPE vendor_status AS ENUM ('active', 'inactive');
CREATE TYPE review_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE application_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE message_status AS ENUM ('unread', 'in_progress', 'resolved');
CREATE TYPE metric_type AS ENUM ('orders', 'revenue', 'users', 'creators');
CREATE TYPE vendor_order_status AS ENUM ('pending', 'accepted', 'in_production', 'completed', 'cancelled');

-- Create tables
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  role user_role NOT NULL DEFAULT 'user',
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  bio TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  UNIQUE (user_id)
);

CREATE TABLE public.creator_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  subdomain_slug TEXT NOT NULL,
  brand_name TEXT NOT NULL,
  brand_description TEXT,
  brand_color TEXT,
  brand_logo_url TEXT,
  payout_info JSONB,
  status creator_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  UNIQUE (subdomain_slug)
);

CREATE TABLE public.loot_boxes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  creator_profile_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  theme TEXT NOT NULL,
  price_tier_1 DECIMAL NOT NULL,
  price_tier_2 DECIMAL,
  price_tier_3 DECIMAL,
  configuration JSONB NOT NULL,
  status box_status NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.loot_box_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  loot_box_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  type item_type NOT NULL,
  design_files JSONB,
  production_specs JSONB NOT NULL,
  vendor_requirements JSONB NOT NULL,
  status item_status NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  loot_box_id UUID NOT NULL,
  shipping_address_id UUID NOT NULL,
  tier_level INTEGER NOT NULL,
  billing_status subscription_status NOT NULL DEFAULT 'active',
  next_billing_date TIMESTAMP WITH TIME ZONE NOT NULL,
  shipping_preferences JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  CONSTRAINT tier_level_check CHECK (tier_level BETWEEN 1 AND 3)
);

CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  subscription_id UUID NOT NULL,
  shipping_address_id UUID NOT NULL,
  status order_status NOT NULL DEFAULT 'pending',
  items JSONB NOT NULL,
  tracking_number TEXT,
  shipping_details JSONB,
  fulfillment_status fulfillment_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.vendors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  capabilities JSONB NOT NULL,
  pricing_details JSONB NOT NULL,
  integration_settings JSONB,
  status vendor_status NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.product_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  item_id UUID NOT NULL,
  reviewer_id UUID NOT NULL,
  status review_status NOT NULL DEFAULT 'pending',
  feedback TEXT,
  approved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.creator_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  status application_status NOT NULL DEFAULT 'pending',
  submitted_materials JSONB NOT NULL,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.shipping_addresses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  street_address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  country TEXT NOT NULL,
  phone TEXT,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.contact_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  email TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status message_status NOT NULL DEFAULT 'unread',
  resolved_at TIMESTAMP WITH TIME ZONE,
  resolved_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.platform_metrics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  metric_type metric_type NOT NULL,
  value JSONB NOT NULL,
  period_start TIMESTAMP WITH TIME ZONE NOT NULL,
  period_end TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE public.vendor_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL,
  vendor_id UUID NOT NULL,
  items JSONB NOT NULL,
  status vendor_order_status NOT NULL DEFAULT 'pending',
  production_details JSONB,
  cost DECIMAL NOT NULL,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  CONSTRAINT vendor_orders_cost_check CHECK (cost >= 0)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loot_boxes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loot_box_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipping_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendor_orders ENABLE ROW LEVEL SECURITY;

-- Create RLS helper function for admin role checks
-- SECURITY DEFINER: Runs with creator's permissions to read profiles
-- STABLE: Enables query-level caching for performance
-- Wrap calls in (SELECT ...) for proper caching: USING ((SELECT is_admin()))

CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT (SELECT role FROM public.profiles WHERE user_id = auth.uid()) IN ('admin', 'super-admin');
$$;

-- Create trigger function for automatic profile creation
-- Automatically creates a profile when a user signs up via Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NULL));
  RETURN NEW;
END;
$$;

-- Create trigger on auth.users table
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create RLS Policies
-- Using native PostgreSQL roles: anon, authenticated
-- Admin policies use authenticated role with is_admin() function check

CREATE POLICY "profiles_select_anon"
  ON public.profiles
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "profiles_select_authenticated"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_select_admin"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "profiles_insert_authenticated"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "profiles_insert_admin"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "profiles_update_authenticated"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "profiles_update_admin"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "profiles_delete_authenticated"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "profiles_delete_admin"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "creator_profiles_select_anon"
  ON public.creator_profiles
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "creator_profiles_select_authenticated"
  ON public.creator_profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "creator_profiles_select_admin"
  ON public.creator_profiles
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "creator_profiles_insert_authenticated"
  ON public.creator_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "creator_profiles_insert_admin"
  ON public.creator_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "creator_profiles_update_authenticated"
  ON public.creator_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "creator_profiles_update_admin"
  ON public.creator_profiles
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "creator_profiles_delete_authenticated"
  ON public.creator_profiles
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "creator_profiles_delete_admin"
  ON public.creator_profiles
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "loot_boxes_select_anon"
  ON public.loot_boxes
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "loot_boxes_select_authenticated"
  ON public.loot_boxes
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "loot_boxes_select_admin"
  ON public.loot_boxes
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "loot_boxes_insert_authenticated"
  ON public.loot_boxes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "loot_boxes_insert_admin"
  ON public.loot_boxes
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "loot_boxes_update_authenticated"
  ON public.loot_boxes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "loot_boxes_update_admin"
  ON public.loot_boxes
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "loot_boxes_delete_authenticated"
  ON public.loot_boxes
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "loot_boxes_delete_admin"
  ON public.loot_boxes
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "loot_box_items_select_anon"
  ON public.loot_box_items
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "loot_box_items_select_authenticated"
  ON public.loot_box_items
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "loot_box_items_select_admin"
  ON public.loot_box_items
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "loot_box_items_insert_authenticated"
  ON public.loot_box_items
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "loot_box_items_insert_admin"
  ON public.loot_box_items
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "loot_box_items_update_authenticated"
  ON public.loot_box_items
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "loot_box_items_update_admin"
  ON public.loot_box_items
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "loot_box_items_delete_authenticated"
  ON public.loot_box_items
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "loot_box_items_delete_admin"
  ON public.loot_box_items
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "subscriptions_select_anon"
  ON public.subscriptions
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "subscriptions_select_authenticated"
  ON public.subscriptions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "subscriptions_select_admin"
  ON public.subscriptions
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "subscriptions_insert_authenticated"
  ON public.subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "subscriptions_insert_admin"
  ON public.subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "subscriptions_update_authenticated"
  ON public.subscriptions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "subscriptions_update_admin"
  ON public.subscriptions
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "subscriptions_delete_authenticated"
  ON public.subscriptions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "subscriptions_delete_admin"
  ON public.subscriptions
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "orders_select_anon"
  ON public.orders
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "orders_select_authenticated"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "orders_select_admin"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "orders_insert_authenticated"
  ON public.orders
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "orders_insert_admin"
  ON public.orders
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "orders_update_authenticated"
  ON public.orders
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "orders_update_admin"
  ON public.orders
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "orders_delete_authenticated"
  ON public.orders
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "orders_delete_admin"
  ON public.orders
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "vendors_select_anon"
  ON public.vendors
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "vendors_select_authenticated"
  ON public.vendors
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "vendors_select_admin"
  ON public.vendors
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "vendors_insert_admin"
  ON public.vendors
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "vendors_update_admin"
  ON public.vendors
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "vendors_delete_admin"
  ON public.vendors
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "product_reviews_select_anon"
  ON public.product_reviews
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "product_reviews_select_authenticated"
  ON public.product_reviews
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "product_reviews_select_admin"
  ON public.product_reviews
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "product_reviews_insert_admin"
  ON public.product_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "product_reviews_update_admin"
  ON public.product_reviews
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "product_reviews_delete_admin"
  ON public.product_reviews
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "creator_applications_select_anon"
  ON public.creator_applications
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "creator_applications_select_authenticated"
  ON public.creator_applications
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "creator_applications_select_admin"
  ON public.creator_applications
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "creator_applications_insert_authenticated"
  ON public.creator_applications
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "creator_applications_insert_admin"
  ON public.creator_applications
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "creator_applications_update_authenticated"
  ON public.creator_applications
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "creator_applications_update_admin"
  ON public.creator_applications
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "creator_applications_delete_authenticated"
  ON public.creator_applications
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "creator_applications_delete_admin"
  ON public.creator_applications
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "shipping_addresses_select_anon"
  ON public.shipping_addresses
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "shipping_addresses_select_authenticated"
  ON public.shipping_addresses
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "shipping_addresses_select_admin"
  ON public.shipping_addresses
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "shipping_addresses_insert_authenticated"
  ON public.shipping_addresses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "shipping_addresses_insert_admin"
  ON public.shipping_addresses
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "shipping_addresses_update_authenticated"
  ON public.shipping_addresses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "shipping_addresses_update_admin"
  ON public.shipping_addresses
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "shipping_addresses_delete_authenticated"
  ON public.shipping_addresses
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "shipping_addresses_delete_admin"
  ON public.shipping_addresses
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "contact_messages_select_anon"
  ON public.contact_messages
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "contact_messages_select_authenticated"
  ON public.contact_messages
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "contact_messages_select_admin"
  ON public.contact_messages
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "contact_messages_insert_authenticated"
  ON public.contact_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "contact_messages_insert_admin"
  ON public.contact_messages
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "contact_messages_update_authenticated"
  ON public.contact_messages
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "contact_messages_update_admin"
  ON public.contact_messages
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "contact_messages_delete_authenticated"
  ON public.contact_messages
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "contact_messages_delete_admin"
  ON public.contact_messages
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "platform_metrics_select_anon"
  ON public.platform_metrics
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "platform_metrics_select_authenticated"
  ON public.platform_metrics
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "platform_metrics_select_admin"
  ON public.platform_metrics
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "platform_metrics_insert_admin"
  ON public.platform_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "platform_metrics_update_admin"
  ON public.platform_metrics
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "platform_metrics_delete_admin"
  ON public.platform_metrics
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "vendor_orders_select_anon"
  ON public.vendor_orders
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "vendor_orders_select_authenticated"
  ON public.vendor_orders
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "vendor_orders_select_admin"
  ON public.vendor_orders
  FOR SELECT
  TO authenticated
  USING ((SELECT is_admin()));

CREATE POLICY "vendor_orders_insert_admin"
  ON public.vendor_orders
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "vendor_orders_update_admin"
  ON public.vendor_orders
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin()))
  WITH CHECK ((SELECT is_admin()));

CREATE POLICY "vendor_orders_delete_admin"
  ON public.vendor_orders
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin()));
```
